args<-commandArgs(TRUE)
t<-read.table(args[1],header=F,row.names=1)
c<-read.table(args[2],header=F,row.names=1)
for (i in 1:nrow(t)) {
tt<-t.test(t[i,],c[i,],alternative="two.sided",mu=0,paired=F,var.equal=F,conf.level=0.95)
p<-paste(row.names(t[i,]),tt$p.value,sep="\t")
write(p,file=args[3],append=T)
}
