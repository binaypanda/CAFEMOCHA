#!/bin/bash

cat <(head -1 ./discover_R_Output/Adjusted_fDMR_dasenNormalizedBetas_forComBat_HNSC.txt) <(awk -F"\t" '{if ($13 < 0.05) print $2"\t"$3-1"\t"$4}' ./discover_R_Output/fDMR_funcNormalizedDmrNT_HNSC | sed 's/\"//g' | grep chr | intersectBed -a - -b probe_cpos.bed -loj | cut -f4-7 | sed 's/^chr//g' |intersectBed -a - -b <(sortBed -i <(cat TSS200.bed TSS1500.bed Island.bed Promoter.bed | sort -u)) -loj | grep -vE '\-1' | cut -f1-4 | sort -k4,4 | join -1 4 -2 1 -t $'\t' - <(grep -v None probe.bed | cut -f4-5 | sort -k1,1) | join -1 1 -2 1 -t $'\t' - <(tail -n+2 ./discover_R_Output/Adjusted_fDMR_dasenNormalizedBetas_forComBat_HNSC.txt | sed 's/\"//g' | sort -k1,1)) > fDMR_dasenNormalizedBetas_TSS200_TSS1500_Island_PromoterDMR_qval0.05_HNSC

join -1 1 -2 1 -t $'\t' <(head -1 fDMR_dasenNormalizedBetas_TSS200_TSS1500_Island_PromoterDMR_qval0.05_HNSC | tr '\t' '\n' | awk '{print $0"\t"NR}' | sort -k1,1) <(sort -k1,1 Sample_Sheet_forComBat2_BRCA | cut -f1-2)

cat <(join -1 1 -2 1 -t $'\t' <(head -1 fDMR_dasenNormalizedBetas_Island_Promoter_TSS200_TSS1500_qval0.05_BRCA | tr '\t' '\n' | awk '{print $0"\t"NR}' | sort -k1,1) <(sort -k1,1 Sample_Sheet_forComBat2_BRCA | cut -f1-2) | sort -k2,2g | cut -f3 | xargs | awk '{print "ProbeID\tChr\tStart\tEnd\tGene\t"$0}') <(tail -n+2 fDMR_dasenNormalizedBetas_Island_Promoter_TSS200_TSS1500_qval0.05_BRCA) | cut -f1,6- > ./TCGA_HNSC_hMethyl450-2015-02-24/genomicMatrix



