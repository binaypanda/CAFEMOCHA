cat <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_exp_HiSeqV2-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f3 | xargs | sed 's/ /\t/g' | awk '{print "M\t"$0}') <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_exp_HiSeqV2-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f2 | xargs | sed 's/ /\"\\t\"\$/g' | sed 's/^/\$1\"\\t\"\$/g' | awk '{print "awk '\''{print "$0"}'\'' ../../default/TCGA_CANCERTYPE_exp_HiSeqV2-2015-02-24/genomicMatrix"}' | bash) > expr_genomicMatrix

cat <(head -2 expr_genomicMatrix) <(join -1 1 -2 1 -t $'\t' <(tail -n+3 expr_genomicMatrix | sort -k1,1) <(sort -k1,1 ../functional.filter)) > exprFF_genomicMatrix

join -1 2 -2 2 -t $'\t' <(head -1 exprFF_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" exprFF_genomicMatrix";}' | bash > exprFF_A_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 exprFF_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" exprFF_genomicMatrix";}' | bash > exprFF_B_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 exprFF_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" exprFF_genomicMatrix";}' | bash > exprFF_C_genomicMatrix

paste -d"\t" <(tail -n+3 exprFF_A_genomicMatrix | awk '{s=$1;min=1000;max=-1000;for (i=2;i<=NF;i++) {if ($i < min) min=$i; if ($i > max) max=$i;} print $1"\t"min"\t"max;}') <(tail -n+3 exprFF_B_genomicMatrix | awk '{s=$1;min=1000;max=-1000;for (i=2;i<=NF;i++) {if ($i < min) min=$i; if ($i > max) max=$i;} print min"\t"max;}') <(tail -n+3 exprFF_C_genomicMatrix | awk '{s=$1;min=1000;max=-1000;for (i=2;i<=NF;i++) {if ($i < min) min=$i; if ($i > max) max=$i;} print min"\t"max;}') | awk '{max1=-1000;max2=-1000;max3=-1000;max4=-1000;min1=1000;min2=1000;min3=1000;min4=1000;if ($2 > max1) max1=$2; if ($4 > max1) max1=$4;if($3 < min1) min1=$3; if ($5 < min1) min1=$5; if ($4 > max2) max2=$4; if ($6 > max2) max2=$6; if ($5 < min2) min2=$5; if ($7 < min2) min2=$7; if ($2 > max3) max3=$2; if ($6 > max3) max3=$6; if ($3 < min3) min3=$3; if ($7 < min3) min3=$7; if ($2 > max4) max4=$2; if ($4 > max4) max4=$4; if ($6 > max4) max4=$6; if ($3 < min4) min4=$3; if ($5 < min4) min4=$5; if ($7 < min4) min4=$7; print $0"\t"max1"\t"min1"\t"max2"\t"min2"\t"max3"\t"min3"\t"max4"\t"min4}' > exprFF_boundaries

paste -d"\t" <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 exprFF_boundaries) <(tail -n+3 exprFF_A_genomicMatrix | sort -k1,1) | awk '{s=$1;for (i=16;i<=NF;i++) {count1=0;count2=0;count3=0;count12=0;count13=0;count23=0;count123=0;if ($i >= $2 && $i <= $3) count1++; if ($i >= $4 && $i <= $5) count2++; if ($i >= $6 && $i <= $7) count3++; if ($i >= $8 && $i <= $9) count12++; if ($i >= $10 && $i <= $11) count23++; if ($i >= $12 && $i <= $13) count13++; if ($i >= $14 && $i <= $15) count123++;s=s"\t"count1-count12-count13+count123;} print s;}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 exprFF_boundaries) <(tail -n+3 exprFF_B_genomicMatrix | sort -k1,1) | awk '{s="";for (i=16;i<=NF;i++) {count1=0;count2=0;count3=0;count12=0;count13=0;count23=0;count123=0;if ($i >= $2 && $i <= $3) count1++; if ($i >= $4 && $i <= $5) count2++; if ($i >= $6 && $i <= $7) count3++; if ($i >= $8 && $i <= $9) count12++; if ($i >= $10 && $i <= $11) count23++; if ($i >= $12 && $i <= $13) count13++; if ($i >= $14 && $i <= $15) count123++;s=s"\t"count2-count12-count23+count123;} print s;}' | sed 's/1/2/g') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 exprFF_boundaries) <(tail -n+3 exprFF_C_genomicMatrix | sort -k1,1) | awk '{s="";for (i=16;i<=NF;i++) {count1=0;count2=0;count3=0;count12=0;count13=0;count23=0;count123=0;if ($i >= $2 && $i <= $3) count1++; if ($i >= $4 && $i <= $5) count2++; if ($i >= $6 && $i <= $7) count3++; if ($i >= $8 && $i <= $9) count12++; if ($i >= $10 && $i <= $11) count23++; if ($i >= $12 && $i <= $13) count13++; if ($i >= $14 && $i <= $15) count123++;s=s"\t"count3-count23-count13+count123;} print s;}' | sed 's/1/3/g') | sed 's/\t[\t]*/\t/g' > expr_specific

join -1 1 -2 1 -t $'\t' <(cat <(tail -n+3 expr_specific | grep -Evw '2|3' | grep -Ew '1' | cut -f1) <(tail -n+3 expr_specific | grep -Evw '1|3' | grep -Ew '2' | cut -f1) <(tail -n+3 expr_specific | grep -Evw '1|2' | grep -Ew '3' | cut -f1) | sort -k1,1) <(tail -n+3 expr_genomicMatrix | sort -k1,1) > exprT_genomicMatrix

join -1 1 -2 1 -t $'\t' <(cat <(tail -n+3 expr_specific | grep -Evw '2|3' | grep -Ew '1' | cut -f1) <(tail -n+3 expr_specific | grep -Evw '1|3' | grep -Ew '2' | cut -f1) <(tail -n+3 expr_specific | grep -Evw '1|2' | grep -Ew '3' | cut -f1) | sort -k1,1) <(head -1 TCGA_BRCA_exp_HiSeqV2-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | grep -E '\-11$|\-10$' | cut -f1 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | sed 's/$/ \.\.\/\.\.\/default\/TCGA_CANCERTYPE_exp_HiSeqV2\-2015\-02\-24\/genomicMatrix/g' | bash | tail -n+2 | sort -k1,1) > exprC_genomicMatrix


join -1 1 -2 1 -t $'\t' <(cut -f1-7 exprFF_boundaries | sort -k1,1) <(awk '{s=$1;min=1000;max=-1000;for (i=2;i<=NF;i++) {if ($i < min) min=$i; if ($i > max) max=$i;} print $1"\t"min"\t"max;}' exprC_genomicMatrix | sort -k1,1) | awk '{print $1"\t"log(((2^$2)-1)/((2^$9)-1))/log(2)"\t"log(((2^$3)-1)/((2^$8)-1))/log(2)"\t"log(((2^$4)-1)/((2^$9)-1))/log(2)"\t"log(((2^$5)-1)/((2^$8)-1))/log(2)"\t"log(((2^$6)-1)/((2^$9)-1))/log(2)"\t"log(((2^$7)-1)/((2^$8)-1))/log(2)}' | grep -v inf | awk '{max1=-1000;max2=-1000;max3=-1000;max4=-1000;min1=1000;min2=1000;min3=1000;min4=1000;if ($2 > max1) max1=$2; if ($4 > max1) max1=$4;if($3 < min1) min1=$3; if ($5 < min1) min1=$5; if ($4 > max2) max2=$4; if ($6 > max2) max2=$6; if ($5 < min2) min2=$5; if ($7 < min2) min2=$7; if ($2 > max3) max3=$2; if ($6 > max3) max3=$6; if ($3 < min3) min3=$3; if ($7 < min3) min3=$7; if ($2 > max4) max4=$2; if ($4 > max4) max4=$4; if ($6 > max4) max4=$6; if ($3 < min4) min4=$3; if ($5 < min4) min4=$5; if ($7 < min4) min4=$7; print $0"\t"max1"\t"min1"\t"max2"\t"min2"\t"max3"\t"min3"\t"max4"\t"min4}' > exprRFF_boundaries

rm pvalue_exp  2>/dev/null
Rscript unpairedP.R exprT_genomicMatrix exprC_genomicMatrix pvalue_exp
awk '{if ($2 <= 0.05) print $1}' pvalue_exp > diffExp_geneList
cat <(head -2 expr_specific) <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 diffExp_geneList) <(tail -n+3 expr_specific | sort -k1,1)) > T; mv expr_specific expr_old_specific; mv T expr_specific

join -1 1 -2 1 -t $'\t' <(intersectBed -a <(cat bedfiles | sort -u | sortBed -i -) -b <(sed 's/chr//g' ../probe_cpos.bed | sortBed -i -) -loj | grep -vEw '\-1' | cut -f7 | sort -k1,1) <(cut -f4-5 ../probe.bed | sort -k1,1) > probes_gene_region

awk -F"[,\t]" '{for (i=2;i<=NF;i++) print $1"\t"$i}' probes_gene_region > T; mv T probes_gene_region

grep -vE None probes_gene_region > T; mv T probes_gene_region

cat <(head -1 ../../default/TCGA_CANCERTYPE_hMethyl450-2015-02-24/genomicMatrix) <(join -1 1 -2 1 -t $'\t' <(cut -f1 probes_gene_region | sort -u | sort -k1,1) <(tail -n+2 ../../default/TCGA_CANCERTYPE_hMethyl450-2015-02-24/genomicMatrix | sort -k1,1)) > T

cat <(join -1 2 -2 1 -t $'\t' <(head -1 T | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f3 | xargs | sed 's/ /\t/g' | awk '{print "M\t"$0}') <(join -1 2 -2 1 -t $'\t' <(head -1 T | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f2 | xargs | sed 's/ /\"\\t\"\$/g' | sed 's/^/\$1\"\\t\"\$/g' | awk '{print "awk '\''{print "$0"}'\'' T"}' | bash) > meth_genomicMatrix

cat <(head -2 meth_genomicMatrix | awk '{s=$1"\tGene";for (i=2;i<=NF;i++) s=s"\t"$i; print s;}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 probes_gene_region) <(tail -n+3 meth_genomicMatrix | sort -k1,1)) > methG_genomicMatrix

cat <(head -2 meth_genomicMatrix | awk '{s="GeneE\tGeneM\tProbe";for (i=2;i<=NF;i++) s=s"\t"$i;print s;}') <(join -1 1 -2 2 -t $'\t' <(sort -k1,1 ../functional.filter) <(join -1 1 -2 2 -t $'\t' <(cat <(cut -f2 methG_genomicMatrix | awk '{print $1"\t"$1;}') ../MIR_target_12May2016 | sort -u | sort -k1,1) <(tail -n+3 methG_genomicMatrix | sort -k2,2) | sort -k2,2)) > methGE_genomicMatrix

cat <(head -2 methGE_genomicMatrix) <(tail -n+3 methGE_genomicMatrix | grep -vE 'NA') > T; mv T methGE_genomicMatrix

join -1 2 -2 2 -t $'\t' <(head -1 methGE_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1-3,/g' | awk '{print $0" methGE_genomicMatrix";}' | bash > methGFF_A_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 methGE_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1-3,/g' | awk '{print $0" methGE_genomicMatrix";}' | bash > methGFF_B_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 methGE_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1-3,/g' | awk '{print $0" methGE_genomicMatrix";}' | bash > methGFF_C_genomicMatrix

awk '{s=$1"_"$2"_"$3;for (i=4;i<=NF;i++) s=s"\t"$i; print s;}' methGFF_A_genomicMatrix > T; mv T methGFF_A_genomicMatrix
awk '{s=$1"_"$2"_"$3;for (i=4;i<=NF;i++) s=s"\t"$i; print s;}' methGFF_B_genomicMatrix > T; mv T methGFF_B_genomicMatrix
awk '{s=$1"_"$2"_"$3;for (i=4;i<=NF;i++) s=s"\t"$i; print s;}' methGFF_C_genomicMatrix > T; mv T methGFF_C_genomicMatrix

cat <(paste -d"\t" <(head -2 methGFF_A_genomicMatrix) <(head -2 methGFF_B_genomicMatrix | cut -f2-) <(head -2 methGFF_C_genomicMatrix | cut -f2-)) expr_specific > T; mv T expr_specific

cat <(head -2 expr_specific) <(tail -n+3 expr_specific | grep -Ew '1' | grep -Evw '2|3') <(tail -n+3 expr_specific | grep -Ew '2' | grep -Evw '1|3') <(tail -n+3 expr_specific | grep -Ew '3' | grep -Evw '1|2') > expr_v_specific

cat <(head -2 expr_genomicMatrix) <(join -1 1 -2 1 -t $'\t' <(tail -n+3 expr_genomicMatrix | awk '{s=$1; for (i=2;i<=NF;i++) s=s"\t"$i; print s;}' | sort -k1,1) <(awk '{s=$1;min=1000;max=-1000;for (i=2;i<=NF;i++) {if ($i < min) min=$i; if ($i > max) max=$i;} print $1"\t"log(2^min-1)/log(2);}' exprC_genomicMatrix | sort -k1,1) | awk '{s=$1; for (i=2;i<=NF-1;i++) s=s"\t"log((2^$i-1)/(2^$(NF)-1))/log(2);print s;}') | grep -v inf | grep -v nan > exprR_genomicMatrix








