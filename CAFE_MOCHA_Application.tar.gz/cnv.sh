cat <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_gistic2thd-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f3 | xargs | sed 's/ /\t/g' | awk '{print "M\t"$0}') <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_gistic2thd-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f2 | xargs | sed 's/ /\"\\t\"\$/g' | sed 's/^/\$1\"\\t\"\$/g' | awk '{print "awk '\''{print "$0"}'\'' ../../default/TCGA_CANCERTYPE_gistic2thd-2015-02-24/genomicMatrix"}' | bash) > cnv_genomicMatrix

join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == 2) count++;} if (count > 0) {print;}}' > cnv_ins_A_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == 2) count++;} if (count > 0) {print;}}' > cnv_ins_B_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == 2) count++;} if (count > 0) {print;}}' > cnv_ins_C_genomicMatrix

join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == -2) count++;} if (count > 0) {print;}}' > cnv_del_A_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == -2) count++;} if (count > 0) {print;}}' > cnv_del_B_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 cnv_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i == -2) count++;} if (count > 0) {print;}}' > cnv_del_C_genomicMatrix

cut -f1 cnv_ins_A_genomicMatrix > I_A
cut -f1 cnv_ins_B_genomicMatrix > I_B
cut -f1 cnv_ins_C_genomicMatrix > I_C
cut -f1 cnv_del_C_genomicMatrix > D_C
cut -f1 cnv_del_B_genomicMatrix > D_B
cut -f1 cnv_del_A_genomicMatrix > D_A

join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_B ) <(sort -k1,1 ../functional.filter) > T; mv T I_B
join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_C ) <(sort -k1,1 ../functional.filter) > T; mv T I_C
join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_A ) <(sort -k1,1 ../functional.filter) > T; mv T I_A
join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_B ) <(sort -k1,1 ../functional.filter) > T; mv T D_B
join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_C ) <(sort -k1,1 ../functional.filter) > T; mv T D_C
join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_A ) <(sort -k1,1 ../functional.filter) > T; mv T D_A

grep -vEw $(cat I_C I_B | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') I_A > I_A.sp
grep -vEw $(cat I_A I_B | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') I_C > I_C.sp
grep -vEw $(cat I_A I_C | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') I_B > I_B.sp
grep -vEw $(cat D_A D_C | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') D_B > D_B.sp
grep -vEw $(cat D_A D_B | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') D_C > D_C.sp
grep -vEw $(cat D_C D_B | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') D_A > D_A.sp

cat <(head -2 cnv_genomicMatrix) <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_A.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t\-2/\t0/g' | sort -k1,1) | sed 's/\t2/\t1/g' | awk '{print "I_"$0}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_B.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t\-2/\t0/g' | sort -k1,1) | awk '{print "I_"$0}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 I_C.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t\-2/\t0/g' | sort -k1,1) | sed 's/\t2/\t3/g' | awk '{print "I_"$0}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_A.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t2/\t0/g' | sort -k1,1) | sed 's/\t\-2/\t1/g' | awk '{print "D_"$0}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_B.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t2/\t0/g' | sort -k1,1) | sed 's/\t\-2/\t2/g' | awk '{print "D_"$0}') <(join -1 1 -2 1 -t $'\t' <(sort -k1,1 D_C.sp) <(tail -n+3 cnv_genomicMatrix | sed 's/\t1/\t0/g' | sed 's/\t\-1/\t0/g' | sed 's/\t2/\t0/g' | sort -k1,1) | sed 's/\t\-2/\t3/g' | awk '{print "D_"$0}')  > cnv_specific

join -1 2 -2 2 -t $'\t' <(head -1 cnv_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_specific > cnv_specific_A";}' | bash
join -1 2 -2 2 -t $'\t' <(head -1 cnv_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_specific > cnv_specific_B";}' | bash
join -1 2 -2 2 -t $'\t' <(head -1 cnv_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" cnv_specific > cnv_specific_C";}' | bash

paste -d"\t" cnv_specific_A <(cut -f2- cnv_specific_B) <(cut -f2- cnv_specific_C) > cnv_specific

cat <(head -2 cnv_specific) <(tail -n+3 cnv_specific | grep -Ew '1' | grep -Evw '2|3') <(tail -n+3 cnv_specific | grep -Ew '2' | grep -Evw '1|3') <(tail -n+3 cnv_specific | grep -Ew '3' | grep -Evw '1|2') > cnv_v_specific






