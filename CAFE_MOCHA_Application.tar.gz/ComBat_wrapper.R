args<-commandArgs(TRUE)
source('ComBat.R')
ComBat(args[1],args[2])
