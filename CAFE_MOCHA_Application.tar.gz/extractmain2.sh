#!/bin/bash

cp ../../../default/SampleSheet/Sample_Sheet_forComBat2_HNSC .

cp fDMR_dasenNormalizedBetas_HNSC fDMR_dasenNormalizedBetas_forComBat_HNSC

sed -i 's/\"//g' fDMR_dasenNormalizedBetas_forComBat_HNSC

cat <(join -1 2 -2 2 -t $'\t' <(head -1 fDMR_dasenNormalizedBetas_forComBat_HNSC | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(tail -n+9 ../../../default/SampleSheet/SampleSheet.csv | cut -d"," -f1,6-7 | sed 's/,R/_R/g' | sed 's/,/\t/g' | sort -k2,2) | sort -k2,2g | cut -f3 | xargs | sed 's/ /\t/g' | awk '{print "Probe\t"$0}') <(tail -n+2 fDMR_dasenNormalizedBetas_forComBat_HNSC) > T

mv T fDMR_dasenNormalizedBetas_forComBat_HNSC

cat <(head -1 fDMR_dasenNormalizedBetas_forComBat_HNSC | cut -f2- | tr '\t' '\n') <(cut -f1 Sample_Sheet_forComBat2_HNSC | tail -n+2) | sort -k1,1 | uniq -u







