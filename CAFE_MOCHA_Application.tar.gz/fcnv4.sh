
cat <(head -2 ../cnv/cnv_specific) <(join -1 1 -2 1 -t $'\t' <(awk -F"[_\t]" '{print $2"\t"$0}' <(tail -n+3 ../cnv/cnv_specific) | sort -k1,1) <(join -1 1 -2 1 -t $'\t' <(tail -n+3 ../cnv/cnv_specific | awk -F"[_\t]" '{print $2}' | sort -u | sort -k1,1) <(tail -n+3 ../expr/expr_specific | sort -k1,1) | sort -k1,1) | cut -f2- | awk '{s=$1;for (i=2;i<=((NF-1)/2)+1;i++) {if ($i == $(i + ((NF-1)/2))) s=s"\t"$i; else s=s"\t0";} print s;}' | grep -Ew '1|2|3|4') > fcnv_specific

cat <(head -2 fcnv_specific) <(tail -n+3 fcnv_specific | grep -Ew '1' | grep -Evw '2|3|4') <(tail -n+3 fcnv_specific | grep -Ew '2' | grep -Evw '1|3|4') <(tail -n+3 fcnv_specific | grep -Ew '3' | grep -Evw '1|2|4') <(tail -n+3 fcnv_specific | grep -Ew '4' | grep -Evw '1|2|3') > fcnv_v_specific
