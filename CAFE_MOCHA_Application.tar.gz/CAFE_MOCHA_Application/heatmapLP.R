if (!require("pheatmap")) install.packages("pheatmap", repos="http://cran.us.r-project.org")
if (!require("gplots")) install.packages("gplots", repos="http://cran.us.r-project.org")
library(pheatmap)
library(gplots)
args<-commandArgs(TRUE)
png( 'forHeatmap_PL.png', width=1500, height=4500)
nba <- read.table(args[1], sep="\t", header=TRUE,check.names = FALSE)
rnames <- nba[,3]
nba_matrix <- data.matrix(nba[,3:ncol(nba)])
colnames(nba_matrix)[1:(ncol(nba)-2)] <- paste("Sample", 1:(ncol(nba)-2), sep="")
rownames(nba_matrix) = rnames
fontsize_row = 10 - nrow(nba_matrix) / 15
fontsize_col = 10
my_palette <- colorRampPalette(c("white","red","orange","yellow","green","blue","violet","brown"))(n = 1000)
pheatmap(nba_matrix, col=my_palette, main="Integrated Signature Map", Colv=FALSE, Rowv=FALSE, cluster_cols=F, cluster_rows = F, cexRow=fontsize_row, cexCol=fontsize_col, border_color=NA,legend=FALSE)
dev.off()
