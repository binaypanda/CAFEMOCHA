cat <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f3 | xargs | sed 's/ /\t/g' | awk '{print "M\t"$0}') <(join -1 2 -2 1 -t $'\t' <(head -1 ../../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k1,1 ../4wayOverlappingSamples_subtype) | cut -f2 | xargs | sed 's/ /\"\\t\"\$/g' | sed 's/^/\$1\"\\t\"\$/g' | awk '{print "awk '\''{print "$0"}'\'' ../../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/genomicMatrix"}' | bash) > mut_genomicMatrix

cat <(head -2 mut_genomicMatrix) <(tail -n+3 mut_genomicMatrix | awk '{s=$1;for (i=2;i<=NF;i++) {if ($i > 0) s=s"\t1"; else s=s"\t0";} print s;}') > T; mv T mut_genomicMatrix

join -1 2 -2 2 -t $'\t' <(head -1 mut_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i > 0) count++;} if (count > 0) {print;}}' > mut_A_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 mut_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i > 0) count++;} if (count > 0) {print;}}' > mut_B_genomicMatrix
join -1 2 -2 2 -t $'\t' <(head -1 mut_genomicMatrix | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_genomicMatrix";}' | bash | tail -n+3 | awk '{count=0;for (i=2;i<=NF;i++) {if ($i > 0) count++;} if (count > 0) {print;}}' > mut_C_genomicMatrix

cut -f1 mut_A_genomicMatrix > A
cut -f1 mut_B_genomicMatrix > B
cut -f1 mut_C_genomicMatrix > C
grep -vEw $(cat A B | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') C > C.sp
grep -vEw $(cat A C | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') B > B.sp
grep -vEw $(cat B C | sort -u | xargs | sed 's/ /|/g' | sed 's/\-/\\\-/g' | sed 's/\./\\\./g') A > A.sp

cat <(head -2 mut_genomicMatrix) <(join -1 1 -2 1 -t $'\t' <(join -1 1 -2 1 -t $'\t' <(cat C.sp B.sp A.sp | sort -u | sort -k1,1) <(cut -f4 ../intogen-drivers-data.tsv | sort -k1,1) | sort -k1,1) <(sort -k1,1 mut_genomicMatrix)) > mut_specific

join -1 2 -2 2 -t $'\t' <(head -1 mut_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'A$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_specific > mut_specific_A";}' | bash
join -1 2 -2 2 -t $'\t' <(head -1 mut_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'B$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_specific";}' | bash | sed 's/\t1/\t2/g' > mut_specific_B
join -1 2 -2 2 -t $'\t' <(head -1 mut_specific | tr '\t' '\n' | awk '{print NR"\t"$0}' | sort -k2,2) <(sort -k2,2 ../grouping) | grep -E 'C$' | sort -k2,2g | cut -f2 | xargs | sed 's/ /,/g' | sed 's/^/cut -f1,/g' | awk '{print $0" mut_specific";}' | bash | sed 's/\t1/\t3/g' > mut_specific_C

paste -d"\t" mut_specific_A <(cut -f2- mut_specific_B) <(cut -f2- mut_specific_C) > mut_specific

cat <(head -2 mut_specific) <(tail -n+3 mut_specific | grep -Ew '1' | grep -Evw '2|3') <(tail -n+3 mut_specific | grep -Ew '2' | grep -Evw '1|3') <(tail -n+3 mut_specific | grep -Ew '3' | grep -Evw '1|2') > mut_v_specific

