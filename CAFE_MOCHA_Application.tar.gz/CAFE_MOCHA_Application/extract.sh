#!/bin/bash

if [ "$1" == "OS" ]; then

head -1 ../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/clinical_data | tr '\t' '\n' | grep -En 'sampleID|clinicalvar' |  cut -d":" -f1 | xargs | sed 's/ /,/g' | awk '{print "cut -f"$0" ../default/*/clinical_data | grep -v sample | sort -u | sed '\''s/\\t[\\t]*$//g'\'' | sed '\''s/ [ ]*$//g'\'' | sed '\''s/\\t$//g'\'' | sed '\''s/\\t1$/\\tY/g'\'' | sed '\''s/\\t0$/\\tN/g'\''  > sample_subtype"}' | bash

else

head -1 ../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/clinical_data | tr '\t' '\n' | grep -En 'sampleID|clinicalvar' |  cut -d":" -f1 | xargs | sed 's/ /,/g' | awk '{print "cut -f"$0" ../default/*/clinical_data | grep -v sample | sort -u | sed '\''s/\\t[\\t]*$//g'\'' | sed '\''s/ [ ]*$//g'\'' | sed '\''s/\\t$//g'\'' > sample_subtype"}' | bash

fi

awk '{if (NF == 1) print $0"\tNA"; else print $0;}' sample_subtype > T; mv T sample_subtype

head -1 ../default/*4/genomicMatrix | tr '\t' '\n' | sort | uniq -c | grep TCGA | sed 's/^[ ]*//g' | grep -E '^4' | cut -d" " -f2 > 4wayOverlappingSamples

join -1 1 -2 1 -t $'\t' <(sort -k1,1 4wayOverlappingSamples) <(sort -k1,1 sample_subtype) > 4wayOverlappingSamples_subtype


#head -1 ../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/clinical_data | tr '\t' '\n' | grep -En 'sampleID|clinical_M' |  cut -d":" -f1 | xargs | sed 's/ /,/g' | awk '{print "cut -f"$0" ../default/*/clinical_data | grep -v sample | sort -u > sample_clinicalM"}' | bash

#head -1 ../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/clinical_data | tr '\t' '\n' | grep -En 'sampleID|pathologic_M' |  cut -d":" -f1 | xargs | sed 's/ /,/g' | awk '{print "cut -f"$0" ../default/*/clinical_data | grep -v sample | sort -u > sample_pathologicM"}' | bash

#join -1 1 -2 1 -t $'\t' <(sort -k1,1 sample_clinicalM) <(sort -k1,1 sample_pathologicM) | awk '{if (NF == 2) print; else if ($2 == $3) print $1"\t"$2; else if ($0 ~ /M0/ && $0 ~ /MX/) print $1"\tMX";}' | sed 's/ /\t/g' > sample_consolidatedM

#

#

#

#head -1 ../default/TCGA_CANCERTYPE_mutation_broad_gene-2015-02-24/clinical_data | tr '\t' '\n' | grep -En 'sampleID|clinicalvar' |  cut -d":" -f1 | xargs | sed 's/ /,/g' | awk '{print "cut -f"$0" ../default/*/clinical_data | grep -v sample | sort -u > sample_recurrence"}' | bash

#

#join -1 1 -2 1 -t $'\t' <(sort -k1,1 sample_consolidatedM) <(sort -k1,1 sample_recurrence) | awk -F"\t" '{if (NF == 2) print; else if ($2 ~ /M0/ && $3 == 1) print $1"\tR"; else print $1"\t"$2;}' | sed 's/ /\t/g' > sample_consolidatedMR

#sed -i 's/\t$//g' sample_consolidatedMR

#awk '{if (NF == 1) print $0"\tNA"; else print $0;}' sample_consolidatedMR > T; mv T sample_consolidatedMR

#head -1 ../default/*4/genomicMatrix | tr '\t' '\n' | sort | uniq -c | grep TCGA | sed 's/^[ ]*//g' | grep -E '^4' | cut -d" " -f2 > 4wayOverlappingSamples

#join -1 1 -2 1 -t $'\t' <(sort -k1,1 4wayOverlappingSamples) <(sort -k1,1 sample_recurrence) > 4wayOverlappingSamples_consolidatedMR


