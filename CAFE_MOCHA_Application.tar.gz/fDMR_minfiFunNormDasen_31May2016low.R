args<-commandArgs(TRUE)
library(minfi)
library(wateRmelon)
targets <- read.450k.sheet(args[4],"csv$")
targets$Basename
RGset <- read.450k.exp(base = args[4], targets = targets, verbose = TRUE)
RGset
pd <- pData(RGset)
pd
set.seed(100)
designMatrix <- model.matrix(~pd$Sample_Group)
gRatioSet.Funnorm <- preprocessFunnorm(RGset, bgCorr = TRUE, dyeCorr = TRUE, sex = NULL)
dmrs <- bumphunter(gRatioSet.Funnorm, designMatrix,cutoff = 0.05, B=1)
write.table(file= args[1],sep="\t",dmrs$table)
setMethod(
   f= "dasen",
   signature(mns="RGChannelSet"),
   definition=function(mns, fudge=100){
   if(!library(minfi, logical.return=TRUE, quietly=TRUE)){
         stop('can\'t load minfi package')
      }
      mns  <- preprocessRaw(mns)    
      dasen ( mns ) 
   }
)
d <- dasen(RGset)
write.table(file= args[2],sep="\t",d)
pd <- pData(RGset)
pd
dmp1 <- dmpFinder(d, pheno=pd$Sample_Group, type="categorical")
write.table(file= args[3],sep="\t",dmp1)

